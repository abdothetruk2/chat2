class GetTop10wall {
    constructor(dao) {
        this.dao = dao;
    }

    createTable() {
        const sql = `
    CREATE TABLE IF NOT EXISTS Top10wall (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      uid VARCHAR(255) DEFAULT "" ,
      otype VARCHAR(255) DEFAULT "" ,
      pic VARCHAR(255) DEFAULT "" ,
      topic VARCHAR(255) DEFAULT "" 

      )`;
   
        return this.dao.run(sql);
    }

    create(data) {
        if (data) {
            return this.dao.run("INSERT INTO Top10wall (uid,otype,pic,topic) VALUES('"+data.lid+"','"+data.otype+"','"+data.pic+"','"+data.topic+"')");
        }
    }
	
	getall(data) {
        if (data) {
          //return this.dao.run(`select count(*) as cc FROM StorieView  WHERE sid =? and topic=? and  idsto = ? and item = ?`, [data.lid,data.topic,data.sid,data.item]);

            return this.dao.get(`SELECT  count(*) as ss FROM StorieView WHERE idsto = ? and item = ? and sid = ?`, [data.idsto,data.item,data.lid]);
        }
    }
	updateTop10wall(data) {
        if (data) {
            return this.dao.run(`UPDATE Top10wall SET topic = ? , pic= ? WHERE uid = ?`, [data.topic,data.pic,data.lid]);
        }
    }

    delete(data) {
        return this.dao.run(`DELETE FROM StorieView WHERE idsto = ?`, [data]);
    }

    getById(data) {
        return this.dao.get(`SELECT topic as t , photo as p FROM StorieView WHERE idsto = "61vapfhq29vost011d2clkjfy6x3hnk" and item = "2" `);
    }

    getop10wall() {
        
        return this.dao.all("SELECT * , count(*) as top FROM `top10wall` GROUP BY uid LIMIT 10 ");
        
    }
    getop10walldet(data){
        return this.dao.all("SELECT * ,count(*) as top FROM `top10wall` WHERE uid='"+data.lid+"' GROUP BY otype ");
    }
}

module.exports = GetTop10wall;
