class GetStorie {
    constructor(dao) {
        this.dao = dao;
    }

    createTable() {
        const sql = `
    CREATE TABLE IF NOT EXISTS storie (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      sid VARCHAR(255) DEFAULT "" ,
      photo VARCHAR(255) DEFAULT "" ,
      name VARCHAR(255) DEFAULT "" ,
      link VARCHAR(255) DEFAULT "" ,
      lastUpdated VARCHAR(255) DEFAULT "" ,
 
      item VARCHAR(2000) DEFAULT '[]',      
      seen BOOLEAN DEFAULT false,
      currentPreview VARCHAR(2000) DEFAULT '[]')`;

        return this.dao.run(sql);
    }

    create(data) {
        if (data) {
            return this.dao.run(`INSERT INTO storie 
                (sid, photo, name, link, item, likes, currentPreview) 
                VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [data.id, data.photo, data.name, data.link, data.item, "0", data.currentPreview]);
        }
    }


    updateStori(data) {
        if (data) {
            return this.dao.run(`UPDATE storie SET currentPreview = currentPreview + 1 WHERE id = ?`, [data.id]);
        }
    }

    updateStori2(data) {
        if (data) {
            return this.dao.run(`UPDATE storie SET likes = likes + 1 WHERE id = ?`, [data.id]);
        }
    }
    delete(data) {
        return this.dao.run(`DELETE FROM storie WHERE name= ?`, [data.name]);
    }
    deleteall() {
        return this.dao.run(`DELETE FROM storie `);
    }

    getById(data) {
        return this.dao.get(`SELECT * FROM storie WHERE sid = ?`, [data]);
    }

    getAll() {
        return this.dao.all(`SELECT * FROM storie`);
    }
}

module.exports = GetStorie;