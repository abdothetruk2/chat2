class GetStorieView {
    constructor(dao) {
        this.dao = dao;
    }

    createTable() {
        const sql = `
    CREATE TABLE IF NOT EXISTS StorieView (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      sid VARCHAR(255) DEFAULT "" ,
      topic VARCHAR(255) DEFAULT "" ,
      photo VARCHAR(255) DEFAULT "" ,
      idsto VARCHAR(255) DEFAULT "" ,
      item INT DEFAULT 0 ,
      time TEXT  )`;
   
        return this.dao.run(sql);
    }

    create(data) {
        if (data) {
            return this.dao.run("INSERT INTO StorieView (sid,topic,photo,idsto,time,likes) VALUES('"+data.id+"','"+data.name+"','"+data.photo+"','"+data.idsto+"','"+data.time+"','"+'0'+"')");
        }
    }
    create2(data) {
        if (data) {
            return this.dao.run("INSERT INTO StorieView (sid,topic,photo,idsto,time,likes) VALUES('"+data.id+"','"+data.name+"','"+data.photo+"','"+data.idsto+"','"+data.time+"','"+'1'+"')");
        }
    }
	
	getall(data) {
        if (data) {
          //return this.dao.run(`select count(*) as cc FROM StorieView  WHERE sid =? and topic=? and  idsto = ? and item = ?`, [data.lid,data.topic,data.sid,data.item]);

            return this.dao.get(`SELECT  count(*) as ss FROM StorieView WHERE idsto = ? and item = ? and sid = ?`, [data.idsto,data.item,data.lid]);
        }
    }
	updateStoriv(data) {
        if (data) {
            return this.dao.run(`UPDATE storie SET item = ? WHERE sid = ?`, [data.item,data.sid]);
        }
    }

    delete(data) {
        return this.dao.run(`DELETE FROM StorieView WHERE idsto = ?`, [data]);
    }

    getById(data) {
        return this.dao.get(`SELECT * from StorieView WHERE sid =? and topic=? `,[data.id,data.name]);
    }
    getById2(data) {
        return this.dao.get(`SELECT * from StorieView WHERE sid =? and likes=1 and topic=? `,[data.id,data.name]);
    }
    getAll() {
        
        return this.dao.all(`SELECT * FROM StorieView`);
        
    }
}

module.exports = GetStorieView;
